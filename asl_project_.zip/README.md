# ASL Alphabet Recognition (CNN)

This project trains a Convolutional Neural Network (CNN) to recognize 29 classes of American Sign Language (A–Z, SPACE, DELETE, NOTHING).

## 📂 Project Structure
- `notebooks/` - Jupyter Notebook for training
- `requirements.txt` - Dependencies
- `asl_model.h5` - Trained model (saved after training)
- `README.md` - Project description

## 🚀 How to Run
1. Clone repo
```bash
git clone https://github.com/YOUR-USERNAME/ASL-Sign-Language-CNN.git
cd ASL-Sign-Language-CNN
```

2. Install dependencies
```bash
pip install -r requirements.txt
```

3. Open notebook
```bash
jupyter notebook notebooks/asl_cnn.ipynb
```
